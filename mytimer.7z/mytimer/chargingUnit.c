#include <msp430.h>
#include <stdint.h>
#include <stdbool.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "rand.h"
#include "crc.h"

#define COORDINATOR 0
#define RANDOM 1
#define EXPON 2
#define GAUSS 3
#define GAUSSMIX 4
#define GEOMATRIX 5
#define DELAYUNIT 0xffff

#define CAR_SIZE 6
#define JOG_SIZE 5
#define OFFICE_Size 5
#define STAIR_SIZE 6
#define WASHER_SIZE 5
#define MAX_LINE_LENGTH 124
int32_t MAX_SUMILATION = 100000000;
char RXData = 0x01;
char TXData = 0x01;
int32_t delayCycles = 0;
int32_t delayCells = 0;
int32_t g_amplifer = 15;
int8_t g_receCounter = 0;
int32_t g_synCounter = 0;
char g_uartArr[6] = {0};
bool chargeSwitch;
bool extendSwitch;
bool uartSwitch = true;
bool reWork;
bool startWork;
bool replySwitch;
int8_t energyMode = COORDINATOR; // COORDINATOR RANDOM EXPON  GAUSSMIX GEOMATRIX GAUSS


void initGPIO()
{

    P1OUT &= ~BIT2;           // Clear P1.0 output latch for a defined power-on state
    P1DIR |= BIT2;            // Set P1.0 to output direction
    P1OUT &= ~BIT0;           // Clear P1.0 output latch for a defined power-on state
    P1DIR |= BIT0;            // Set P1.0 to output direction
    P1OUT &= ~BIT1;           // Clear P1.0 output latch for a defined power-on state
    P1DIR |= BIT1;            // Set P1.0 to output direction
    // LEDs
    P1DIR |= BIT0 | BIT1;
    P1OUT &= ~(BIT0 | BIT1);         // turn off LEDs

    // Configure UART
    P6SEL1 &= ~(BIT0 | BIT1);                 // USCI_A3 UART operation
    P6SEL0 |= BIT0 | BIT1;

    // Configure PJ.5 PJ.4 for external crystal oscillator
    PJSEL0 |= BIT4 | BIT5;                    // For XT1

    // Disable the GPIO power-on default high-impedance mode to activate
    // previously configured port settings
    PM5CTL0 &= ~LOCKLPM5;
}

void uartTimer()
{
    CSCTL0_H = CSKEY_H; // Unlock CS registers
    CSCTL1 = DCOFSEL_0; // Set DCO to 1MHz
    CSCTL2 = SELA__LFXTCLK | SELS__DCOCLK | SELM__DCOCLK;
    CSCTL3 = DIVA__1 | DIVS__1 | DIVM__1; // Set all dividers
    CSCTL4 &= ~LFXTOFF;                   // Enable LFXT1
    do
    {
        CSCTL5 &= ~LFXTOFFG; // Clear XT1 fault flag
        SFRIFG1 &= ~OFIFG;
    } while (SFRIFG1 & OFIFG); // Test oscillator fault flag
    CSCTL0_H = 0;              // Lock CS registers
}
void configUart()
{
    UCA3CTLW0 |= UCSWRST;
    UCA3CTLW0 |= UCSSEL__ACLK; // Set ACLK = 32768 as UCBRCLK
    UCA3BRW = 3;               // 9600 baud
    UCA3MCTLW |= 0x5300;       // 32768/9600 - INT(32768/9600)=0.41
                               // UCBRSx value = 0x53 (See UG)
    UCA3CTLW0 &= ~UCSWRST;     // release from reset
    UCA3IE |= UCRXIE;          // Enable USCI_A3 RX interrupt
}


// generate random integers comply by the geomteric distribution
// 5: 0.835; 120:0.127; 500: 0.044
int geometricRandom(double p)
{
    if (p <= 0 || p > 1)
    {
        exit(EXIT_FAILURE);
    }
    // Generate a random value between 0 and 1(
    double u = (double)rand() / RAND_MAX;
    // Calculate the number of trials until the first success
    int k = (int)ceil(log(1 - u) / log(1 - p));
    return k;
}
// Function to generate random integers within a specified range [min, max]
int generateRandomInt(int min, int max)
{
    return (rand() % (max - min + 1)) + min;
}
// Function to generate integer random numbers from an exponential distribution
int exponentialRand(double lambda, int min, int max)
{
    double u = (double)rand() / RAND_MAX;
    double expo_value = -log(1.0 - u) / lambda;
    return (int)fmax(fmin(expo_value, max), min); // Ensure generated integer is within [min, max]
}
// Function to generate integer random numbers from a Gaussian (Normal) distribution
int gaussianRand(int mu, int sigma, int min, int max)
{
    double u1 = (double)rand() / RAND_MAX;
    double u2 = (double)rand() / RAND_MAX;
    double z = sqrt(-2.0 * log(u1)) * cos(2.0 * M_PI * u2);
    double gaussian_value = mu + sigma * z;
    return (int)fmax(fmin(gaussian_value, max), min); // Ensure generated integer is within [min, max]
}
// Function to generate integer random numbers from a Gaussian mixture distribution
int gaussianMixtureRand(int num_components, int mu[], int sigma[], double weights[], int min, int max)
{
    double u = (double)rand() / RAND_MAX;
    int component = 0;
    while (u > weights[component])
    {
        u -= weights[component];
        component++;
    }
    double u1 = (double)rand() / RAND_MAX;
    double u2 = (double)rand() / RAND_MAX;
    double z = sqrt(-2.0 * log(u1)) * cos(2.0 * M_PI * u2);
    double mixture_value = mu[component] + sigma[component] * z;
    return (int)fmax(fmin(mixture_value, max), min); // Ensure generated integer is within [min, max]
}
// Set energy models
int setEnergyModel(int energyModel)
{
    // Set parameters for each distribution
    double lambda = 0.1;              // For exponential distribution
    int mean = 5;                      // Mean of Gaussian distribution
    int stddev = 2;                   // Standard deviation of Gaussian distribution
    int num_components = 2;           // Number of Gaussian components in the mixture
    int mu_components[] = {30, 70};   // Mean of each component in the mixture
    int sigma_components[] = {5, 10}; // Standard deviation of each component in the mixture
    double weights[] = {0.6, 0.4};    // Weights of each component in the mixture (should sum to 1)
    GaussianComponent components[] = {
               {70.0, 10, 0.7}, // Component 1: mean, stddev, weight
               {30.0, 5,  0.3}  // Component 2: mean, stddev, weight
    };
    int n_components = 2;
    int min = 1;                      // Minimum value of the range
    int max = 10;                    // Maximum value of the range
    switch (energyModel)
    {
    case COORDINATOR:
        return 3;
    case RANDOM:
        return (generateRandomInt(min, max));
    case EXPON:
        return generate_exponential_int(min, max, lambda);
    case GAUSS:
        return generate_normal_positive_int(min, max, mean, stddev);
    case GAUSSMIX:
        return generate_gaussian_mixture_int(components, n_components, min, max);
    case GEOMATRIX:
        return exponentialRand(lambda, min, max);
    default:
        return 0;
    }
}


int32_t combineBytes(char arr[])
{
    return ((int32_t)arr[0] << 24) | ((int32_t)arr[1] << 16) | ((int32_t)arr[2] << 8) | arr[3];
}


int16_t combineBytes2(char arr[])
{
    return ((int16_t)arr[4] << 8) | arr[5];
}


void sendBytes(int32_t num)
{
    int i = 3;
    char tempArr[4];
    char temp2[2];
    for (; i >= 0; i--)
    {
        while (!(UCA3IFG & UCTXIFG))
            ;
        UCA3TXBUF = (num >> (i * 8)) & 0xff;
        tempArr[3 -i] = (num >> (i * 8)) & 0xff;
    }
    i = 1;
    for (; i >= 0; i--)
    {
        while (!(UCA3IFG & UCTXIFG))
            ;
        UCA3TXBUF = ( crcFast(tempArr, 4) >> (i * 8)) & 0xff;
        temp2[i] = ( crcFast(tempArr, 4) >> (i * 8)) & 0xff;
    }
    __no_operation();
}


int main(void)
{
    WDTCTL = WDTPW | WDTHOLD; // stop watchdog
    chargeSwitch = true;
    extendSwitch  = false;
    reWork = false;
    replySwitch = false;
    startWork = false;
    // configure uart
    initGPIO();
    uartTimer();
    configUart();
    crcInit();
    P6SEL0 ^= BIT0;
    //***************************************
    delayCycles =  setEnergyModel(energyMode);
    delayCells  = (delayCycles + 1) * g_amplifer;
    //***************************************
    TA0CCTL0 = CCIE; // TACCR0 interrupt enabled
    TA0CCR0 = DELAYUNIT;
    TA0CTL = TASSEL__SMCLK | MC__CONTINOUS; // SMCLK, continuous mode
    __bis_SR_register(GIE);
    while(uartSwitch)
    {
        if (delayCells == 0)
        {
            P6SEL0 ^= BIT0;
            P1OUT ^= BIT2;
            P1OUT ^= BIT1;
            delayCycles = setEnergyModel(energyMode);
            delayCells = (delayCycles + 1) * g_amplifer;
            chargeSwitch = true;
        }
        if ((delayCells == g_amplifer) && (chargeSwitch == true))
        {
            P6SEL0 ^= BIT0;
            P1OUT ^= BIT2;
            P1OUT ^= BIT1;
            chargeSwitch = false;
            replySwitch = true;
        }

        if ((delayCells == 10) && (replySwitch == true) && (energyMode != COORDINATOR))
        {
            replySwitch = false;
            sendBytes(delayCycles);
            __no_operation();
        }


        if ((delayCells == g_amplifer) && (reWork == true))
        {
            P6SEL0 ^= BIT0;
            P1OUT ^= BIT2;
            P1OUT ^= BIT0;
            reWork = false;
            startWork = true;
        }

        if ((delayCells == 10) && (startWork == true))
        {
            sendBytes(1000);
            startWork = false;
        }

        // uart
        if ((g_receCounter >= 6) && (replySwitch == false) && (delayCells <= 10))
        {
            delayCycles = combineBytes(g_uartArr);
            delayCycles = crcFast(g_uartArr, 4);
            delayCycles = combineBytes2(g_uartArr);
            if ((combineBytes2(g_uartArr) == crcFast(g_uartArr, 4)) && (combineBytes(g_uartArr) > 0))
            {
                delayCells = combineBytes(g_uartArr) - (g_amplifer - delayCells - 1) ;
                extendSwitch = true;
                if (MAX_SUMILATION <= 0)
                {
                    uartSwitch = false;
                    g_synCounter = combineBytes(g_uartArr);
                    __no_operation();
                }
            }
            g_receCounter = 0;
        }
        __no_operation();
    }
}
// Timer0_A0 interrupt service routine
#if defined(__TI_COMPILER_VERSION__) || defined(__IAR_SYSTEMS_ICC__)
#pragma vector = TIMER0_A0_VECTOR
__interrupt void Timer0_A0_ISR(void)
#elif defined(__GNUC__)
void __attribute__((interrupt(TIMER0_A0_VECTOR))) Timer0_A0_ISR(void)
#else
#error Compiler not supported!
#endif
{
    TA0CCR0 += DELAYUNIT; // Add Offset to TA0CCR0
    // for timer
    if ((delayCells > g_amplifer) && extendSwitch && (energyMode != COORDINATOR))
    {
        // Fall into sleeping state again
        P6SEL0 ^= BIT0;
        P1OUT ^= BIT2;
        P1OUT ^= BIT1;
        extendSwitch = false;
        reWork = true;
    }
    if (delayCells > 0)
    {
        delayCells--;
    }
    if (MAX_SUMILATION > 0)
    {
        MAX_SUMILATION--;
    }
}


// UART
#if defined(__TI_COMPILER_VERSION__) || defined(__IAR_SYSTEMS_ICC__)
#pragma vector=USCI_A3_VECTOR
__interrupt void USCI_A3_ISR(void)
#elif defined(__GNUC__)
void __attribute__ ((interrupt(USCI_A3_VECTOR))) USCI_A3_ISR (void)
#else
#error Compiler not supported!
#endif
{
switch(__even_in_range(UCA3IV, USCI_UART_UCTXCPTIFG))
{
    case USCI_NONE: break;
    case USCI_UART_UCRXIFG:
        if (g_receCounter < 6)
        {
            g_uartArr[g_receCounter] = UCA3RXBUF;
        }
        g_receCounter = g_receCounter + 1;
        __no_operation();
        break;
    case USCI_UART_UCTXIFG: break;
    case USCI_UART_UCSTTIFG: break;
    case USCI_UART_UCTXCPTIFG: break;
}
}

