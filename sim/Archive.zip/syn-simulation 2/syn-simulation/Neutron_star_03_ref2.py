



class Cluster:
    numOfCoordinator = 0
    numOfIC = 0
    numOfConverge = 0

    




