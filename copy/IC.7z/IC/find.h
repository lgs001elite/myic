/*
 * find.h
 *
 *  Created on: Dec 20, 2023
 *      Author: glu250
 */

#ifndef FIND_H_
#define FIND_H_

volatile int32_t geometric_distribution(double p);

#endif /* FIND_H_ */
