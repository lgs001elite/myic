/*
 * coordinatorFind.h
 *
 *  Created on: Dec 21, 2023
 *      Author: glu250
 */

#ifndef COORDINATORFIND_H_
#define COORDINATORFIND_H_


#define COORDINATOR_CYCLES 5


#endif /* COORDINATORFIND_H_ */
