#ifndef UARTHEX_H_
#define UARTHEX_H_
#include <stdio.h>
#include <stdint.h>

void transHexBytes(int32_t num);

int32_t combineBytes(char arr[]);
int16_t combineBytes2(char arr[] );
#endif



