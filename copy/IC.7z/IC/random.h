/*
 * random.h
 *
 *  Created on: Dec 20, 2023
 *      Author: glu250
 */


#ifndef RANDOM_H_
#define RANDOM_H_
#include <stdint.h>

int32_t genRanNumb(void);

#endif /* RANDOM_H_ */
