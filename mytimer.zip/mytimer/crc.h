/*
 * crc.h
 *
 *  Created on: Dec 20, 2023
 *      Author: glu250
 */

#ifndef crc_h
#define crc_h
#include <stdint.h>

#define FALSE    0
#define TRUE    !FALSE
#define CRC16

#define CRC_NAME            "CRC-16"
#define POLYNOMIAL           0x8005
#define INITIAL_REMAINDER    0x0000
#define FINAL_XOR_VALUE      0x0000
#define REFLECT_DATA         TRUE
#define REFLECT_REMAINDER    TRUE
#define CHECK_VALUE          0xBB3D

// in crc
#define HISLEN 20

// in crc
void update_crc(void);

// in crc, tx
int16_t getCRC( char const message[]);

void  crcInit(void);
int16_t   crcFast( char const message[], int nBytes);
#endif /* crc_h */
