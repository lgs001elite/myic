#ifndef _RANDOM_H_
#define _RANDOM_H_
#include <stdint.h>

uint32_t genRanNumb(void);

#endif
