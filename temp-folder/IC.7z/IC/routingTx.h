#ifndef _ROUTINGTX_H_
#define _ROUTINGTX_H_

#include <stdint.h>

void produceData(uint8_t packetNum);
void produceNonPacketData(void);

#endif
