import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
from matplotlib.ticker import ScalarFormatter
import csv

# Define your methods, node sets, and scenarios
syn_methods = ["Find", "Flync", "Pulsar", "Free_beacon"]
syn_legend_names = ["Find", "Flync_Find", "Pulsar", "FreeBeacon", "Medians", "Means"]

poweroff_rates = [1, 5, 10]
poweroff_rates_name = ["#1", "#5", "#10"]

energy_scenarios = ["Static_trace", "Complex_trace", "Cars_trace", "Jogging_trace", "Office_trace", "Stairs_trace", "Washer_trace"]
energy_scenarios_names = ["#Static", "#Random", "#Cars trace", "#Jogging trace", "#Office trace", "#Stairs trace", "#Washer trace"]

title ="free_beacon_with_30"
colors = ['steelblue', 'darkorange', 'forestgreen', 'firebrick', "purple", "tomato"]

# Initialize the data_sets list to store your data
data_sets = []
for scenario in energy_scenarios:
    scenario_methods = []
    for method in syn_methods:
        method_node_sets = []
        for rate in poweroff_rates:
            method_node_sets.append([])  # Placeholder for data
        scenario_methods.append(method_node_sets)
    data_sets.append(scenario_methods)

# Collect the data
for i, scenario in enumerate(energy_scenarios):
    for j, method in enumerate(syn_methods):
        for k, rate in enumerate(poweroff_rates):
            file_name = f"poweroff_{method.lower()}_syn_in_{scenario.upper()}_{rate}.csv"
            try:
                with open(file_name, mode='r') as file:
                    csv_reader = csv.reader(file)
                    for row in csv_reader:
                        data_sets[i][j][k].append(int(row[0]))
            except FileNotFoundError:
                print(f"File not found: {file_name}")
                data_sets[i][j][k] = [0]  # Assign a default value or handle as needed

# Reorganize scenario_sets to align with the expected format
scenario_sets = []
for i in range(len(energy_scenarios)):
    scenario_data = []
    for j in range(len(syn_methods)):
        method_data = []
        for k in range(len(poweroff_rates)):
            # Each method_data[j] should be a list of lists, one per node set
            method_data.append(data_sets[i][j][k])
        scenario_data.append(method_data)
    scenario_sets.append(scenario_data)

# Create the figure and axes

plt.rcParams['font.family'] = 'Helvetica'
plt.rcParams.update({'font.size': 18})  # Set font size globally
fig, ax= plt.subplots(1, 7, figsize=(20, 4), sharey=True)

# Set the positions for each group
positions = np.arange(len(poweroff_rates))
bar_width = 0.15  # Adjusted bar width for more methods

# Define colors and hatches for different box groups
box_colors = ['red', 'green', 'orange', 'purple']
box_hatches = ['/', '\\', '|', '-']
median_line_style = '--'
quantile_line_style = ':'

# Function to customize boxplot
def create_custom_boxplot(ax, data_list, positions, labels):
    num_datasets = len(data_list)
    total_width = bar_width * num_datasets
    offsets = np.linspace(-total_width/2 + bar_width/2, total_width/2 - bar_width/2, num_datasets)
    
    for idx, (method_data, label, offset) in enumerate(zip(data_list, labels, offsets)):
        pos = positions + offset
        bp = ax.boxplot(
            method_data,
            positions=pos,
            widths=bar_width,
            patch_artist=True,
            showfliers=False
        )
        
        # Customize boxes
        color = box_colors[idx % len(box_colors)]
        hatch = box_hatches[idx % len(box_hatches)]
        
        for box in bp['boxes']:
            box.set_facecolor(color)
            box.set_hatch(hatch)
            box.set_linewidth(1.5)
        
        # Customize whiskers, caps, and medians
        for whisker in bp['whiskers']:
            whisker.set(linewidth=1.5, linestyle='-', color='black')
    
        for cap in bp['caps']:
            cap.set(linewidth=1.5)
    
        for median in bp['medians']:
            median.set(linewidth=2, linestyle=median_line_style, color='black')
        
        # Add 90th and 99th percentiles as dotted lines
        for i in range(len(method_data)):
            percentile_90 = np.percentile(method_data[i], 90)
            percentile_99 = np.percentile(method_data[i], 99)
            ax.plot(
                [pos[i]] * 2,
                [bp['whiskers'][i * 2 + 1].get_ydata()[1], percentile_90],
                quantile_line_style,
                color='gray'
            )
            ax.plot(
                [pos[i]] * 2,
                [percentile_90, percentile_99],
                quantile_line_style,
                color='purple'
            )
        
        # Add legend labels
        ax.plot([], c=color, label=label, linewidth=1.5)
    
    # Add percentile lines to legend
    ax.plot([], c='black', linestyle=median_line_style, label='Median')
    ax.plot([], c='gray', linestyle=quantile_line_style, label='90th percentile')
    ax.plot([], c='purple', linestyle=quantile_line_style, label='99th percentile')

# Plot the data for each scenario
for i in range(len(energy_scenarios)):
    create_custom_boxplot(ax[i], scenario_sets[i], positions, ["#Find", '#Flync-Find', '#Pulsar', "#FreeBeacon"])
    ax[i].set_xlabel(energy_scenarios_names[i])
    ax[i].set_yscale('log')
    ax[i].set_xticks(positions)
    ax[i].set_xticklabels(poweroff_rates_name)

# Set axis labels and titles
ax[0].set_ylabel('#Syn Time [slots]')

# Add a shared legend
handles, labels = ax[0].get_legend_handles_labels()
fig.legend(handles, labels, loc='upper center', ncol=7)

# Adjust layout and show the plot
plt.tight_layout()
plt.subplots_adjust(top=0.88)  # Adjust to make room for the shared legend
plt.savefig("poweroff_simulation.pdf", format="pdf")
plt.show()


